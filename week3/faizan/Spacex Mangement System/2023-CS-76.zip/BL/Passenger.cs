﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spacex_Mangement_System
{
    internal class Passenger
    {
        public static List<Passenger> passengers = new List<Passenger>();
        public string passengername;
        public string Shipname;

        public Passenger(string passengername, string Shipname) 
        { 
            this.passengername = passengername;
            this.Shipname = Shipname;

        }


        public static void addpassengers()
        {
            if(spaceship.ships.Count == 0)
            {
                Console.WriteLine("No ships available. Please add a ship first.");
                Console.ReadKey();
            }
            else
            {
                Console.WriteLine("Available Ships:");
                for (int i = 0; i < spaceship.ships.Count; i++)
                {
                    Console.WriteLine($"{i + 1}. {spaceship.ships[i].shipname} - Destination: {spaceship.ships[i].destination}");
                }
                
                while(true)
                {
                    Console.Write("Choose a ship number: ");
                    int option = int.Parse(Console.ReadLine());
                    if (option<1||option> spaceship.ships.Count)
                    {
                        Console.WriteLine("Invalid ship selection.Try again");
                    }
                    else
                    {
                        Console.Write("Enter passenger name: ");
                        string passengerName = Console.ReadLine();
                        string shipnName = spaceship.ships[option - 1].shipname;
                        Passenger newPassenger = new Passenger(passengerName, shipnName);
                        passengers.Add(newPassenger);
                        Console.WriteLine($"{passengerName} added to {spaceship.ships[option - 1].shipname} successfully!");
                        Console.ReadKey();
                        break;
                    }
                }
                

            }
        }

        public static void RemovePassenger()
        {
            if (passengers.Count == 0)
            {
                Console.WriteLine("No passengers available.");
                Console.ReadKey();
            }
            else
            {

                Console.WriteLine("Available Passengers:");
                for (int i = 0; i < passengers.Count; i++)
                {
                    Console.WriteLine($"{i + 1}. {passengers[i].passengername} - Ship: {passengers[i].Shipname}");
                }

                Console.Write("Choose a passenger number to remove: ");
                int passengerIndex = int.Parse(Console.ReadLine()) - 1;
                while (true)
                {
                    if (passengerIndex < 0 || passengerIndex >= passengers.Count)
                    {
                        Console.WriteLine("Invalid passenger selection.");
                        Console.ReadKey();
                    }
                    else
                    {
                        passengers.RemoveAt(passengerIndex);
                        Console.WriteLine("Passenger removed successfully!");
                        Console.ReadKey();
                        break;
                    }
                }
            }
        }
        public static void Viewpassengerslist()
        {
            if(passengers.Count==0)
            {
                Console.WriteLine("Sorry there are no passengers!");
                Console.ReadKey();
            }
            else
            {
                Console.WriteLine($"Passenger's name\tPassenger's ship name");
                for(int i=0;i<passengers.Count;i++)
                {
                    Console.WriteLine($"{passengers[i].passengername}\t\t{passengers[i].Shipname}");
                }
                Console.ReadKey();
            }
        }
    }
    

}
